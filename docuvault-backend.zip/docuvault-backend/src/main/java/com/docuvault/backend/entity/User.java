package com.docuvault.backend.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity // Tells JPA that this class represents a database table
public class User { // Defines the User entity

    @Id // Marks id as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Automatically generates the ID
    private Long id;

    private String name; // Stores the user's name

    @Column(unique = true, nullable = false) // Email must be unique and cannot be null
    private String email;

    private String password; // Stores the encrypted password

    private String role; // Stores the user's role such as ADMIN, MANAGER or EMPLOYEE

    private LocalDateTime createdAt; // Stores when the user was created

    private LocalDateTime updatedAt; // Stores when the user was updated

    public Long getId() { // Gets the user ID
        return id;
    }

    public void setId(Long id) { // Sets the user ID
        this.id = id;
    }

    public String getName() { // Gets the user's name
        return name;
    }

    public void setName(String name) { // Sets the user's name
        this.name = name;
    }

    public String getEmail() { // Gets the user's email
        return email;
    }

    public void setEmail(String email) { // Sets the user's email
        this.email = email;
    }

    public String getPassword() { // Gets the user's password
        return password;
    }

    public void setPassword(String password) { // Sets the user's password
        this.password = password;
    }

    public String getRole() { // Gets the user's role
        return role;
    }

    public void setRole(String role) { // Sets the user's role
        this.role = role;
    }

    public LocalDateTime getCreatedAt() { // Gets the creation time
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) { // Sets the creation time
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() { // Gets the update time
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) { // Sets the update time
        this.updatedAt = updatedAt;
    }
}