package com.docuvault.backend.repository;

import com.docuvault.backend.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

// Connects the AuditLog entity with database operations
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

}