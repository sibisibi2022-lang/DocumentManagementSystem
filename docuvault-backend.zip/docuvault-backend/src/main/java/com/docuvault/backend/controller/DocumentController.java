package com.docuvault.backend.controller;

import com.docuvault.backend.dto.DocumentDTO;
import com.docuvault.backend.service.DocumentService;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(
            DocumentService documentService) {

        this.documentService =
                documentService;
    }

    @PostMapping
    public DocumentDTO createDocument(
            @RequestBody DocumentDTO documentDTO) {

        return documentService.createDocument(
                documentDTO
        );
    }

    @GetMapping
    public List<DocumentDTO> getAllDocuments() {

        return documentService.getAllDocuments();
    }

    @GetMapping("/search")
    public List<DocumentDTO> searchDocuments(
            @RequestParam String keyword) {

        return documentService.searchDocuments(
                keyword
        );
    }

    @GetMapping("/file-type")
    public List<DocumentDTO> searchByFileType(
            @RequestParam String fileType) {

        return documentService.searchByFileType(
                fileType
        );
    }

    @GetMapping("/category/{categoryId}")
    public List<DocumentDTO> getDocumentsByCategory(
            @PathVariable Long categoryId) {

        return documentService
                .getDocumentsByCategory(
                        categoryId
                );
    }

    @GetMapping("/{id}")
    public ResponseEntity<DocumentDTO>
    getDocumentById(
            @PathVariable Long id) {

        return documentService
                .getDocumentById(id)
                .map(ResponseEntity::ok)
                .orElse(
                        ResponseEntity
                                .notFound()
                                .build()
                );
    }

    // Update document and optionally replace file
    @PutMapping(
            value = "/{id}",
            consumes = "multipart/form-data"
    )
    public ResponseEntity<?> updateDocument(
            @PathVariable Long id,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("categoryId") Long categoryId,
            @RequestParam(value = "file", required = false)
            MultipartFile file) {

        try {

            DocumentDTO updatedDocument =
                    documentService.updateDocument(
                            id,
                            title,
                            description,
                            categoryId,
                            file
                    );

            return ResponseEntity.ok(
                    updatedDocument
            );

        } catch (
                DocumentService.DuplicateVersionException e) {

            Map<String, String> response =
                    new HashMap<>();

            response.put(
                    "message",
                    e.getMessage()
            );

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(response);

        } catch (IllegalArgumentException e) {

            Map<String, String> response =
                    new HashMap<>();

            response.put(
                    "message",
                    e.getMessage()
            );

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(response);

        } catch (RuntimeException e) {

            Map<String, String> response =
                    new HashMap<>();

            response.put(
                    "message",
                    e.getMessage()
            );

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(response);

        } catch (IOException e) {

            Map<String, String> response =
                    new HashMap<>();

            response.put(
                    "message",
                    e.getMessage()
            );

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(response);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDocument(
            @PathVariable Long id) {

        documentService.deleteDocument(id);

        return ResponseEntity
                .noContent()
                .build();
    }

    @PostMapping("/upload")
    public DocumentDTO uploadDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("categoryId") Long categoryId)
            throws IOException {

        return documentService.uploadDocument(
                file,
                title,
                description,
                categoryId
        );
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> downloadDocument(
            @PathVariable Long id)
            throws IOException {

        Resource resource =
                documentService.downloadDocument(id);

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" +
                                resource.getFilename() +
                                "\""
                )
                .body(resource);
    }
}