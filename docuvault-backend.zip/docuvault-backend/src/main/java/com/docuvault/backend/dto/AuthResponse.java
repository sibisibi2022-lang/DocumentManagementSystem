
/*
After successful login, the backend needs to send the JWT back to Angular.
The response will look like:

{
  "token": "eyJhbGciOiJIUzI1NiJ9..."
}

So remember:

RegisterRequest → receives registration data
LoginRequest    → receives login data
AuthResponse    → sends JWT back

*/
package com.docuvault.backend.dto;
public class AuthResponse {
    private String token; // Stores the JWT token returned after successful login
    public AuthResponse(String token) { // Constructor used to create the response with a token
        this.token = token;
    }
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }
}