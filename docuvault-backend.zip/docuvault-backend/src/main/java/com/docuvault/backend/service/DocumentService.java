package com.docuvault.backend.service;

import com.docuvault.backend.dto.DocumentDTO;
import com.docuvault.backend.entity.AuditLog;
import com.docuvault.backend.entity.Category;
import com.docuvault.backend.entity.Document;
import com.docuvault.backend.entity.DocumentVersion;
import com.docuvault.backend.entity.User;
import com.docuvault.backend.repository.AuditLogRepository;
import com.docuvault.backend.repository.CategoryRepository;
import com.docuvault.backend.repository.DocumentRepository;
import com.docuvault.backend.repository.DocumentVersionRepository;
import com.docuvault.backend.repository.UserRepository;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final AuditLogRepository auditLogRepository;
    private final DocumentVersionRepository documentVersionRepository;

    public DocumentService(
            DocumentRepository documentRepository,
            UserRepository userRepository,
            CategoryRepository categoryRepository,
            AuditLogRepository auditLogRepository,
            DocumentVersionRepository documentVersionRepository) {

        this.documentRepository = documentRepository;
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.auditLogRepository = auditLogRepository;
        this.documentVersionRepository = documentVersionRepository;
    }

    // Create a new document
    public DocumentDTO createDocument(DocumentDTO documentDTO) {

        Document document = new Document();

        document.setTitle(documentDTO.getTitle());
        document.setDescription(documentDTO.getDescription());
        document.setFileName(documentDTO.getFileName());
        document.setFileType(documentDTO.getFileType());
        document.setFilePath(documentDTO.getFilePath());

        if (documentDTO.getUploadedBy() != null) {

            User user =
                    userRepository
                            .findById(documentDTO.getUploadedBy())
                            .orElseThrow();

            document.setUploadedBy(user);
        }

        if (documentDTO.getCategoryId() != null) {

            Category category =
                    categoryRepository
                            .findById(documentDTO.getCategoryId())
                            .orElseThrow();

            document.setCategory(category);
        }

        Document savedDocument =
                documentRepository.save(document);

        return convertToDTO(savedDocument);
    }

    // Get all documents
    public List<DocumentDTO> getAllDocuments() {

        return documentRepository
                .findAll()
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    // Get one document
    public Optional<DocumentDTO> getDocumentById(Long id) {

        return documentRepository
                .findById(id)
                .map(this::convertToDTO);
    }

    // Update document metadata and optionally replace its file
    public DocumentDTO updateDocument(
            Long id,
            String title,
            String description,
            Long categoryId,
            MultipartFile file) throws IOException {

        Document document =
                documentRepository
                        .findById(id)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Document not found"
                                )
                        );

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        String email =
                authentication.getName();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "User not found"
                                )
                        );

        document.setTitle(title);
        document.setDescription(description);

        if (categoryId != null) {

            Category category =
                    categoryRepository
                            .findById(categoryId)
                            .orElseThrow(
                                    () -> new RuntimeException(
                                            "Category not found"
                                    )
                            );

            document.setCategory(category);
        }

        // Replace file and automatically create a new version
        if (file != null && !file.isEmpty()) {

            createVersionForUpdate(
                    document,
                    user,
                    file
            );
        }

        Document updatedDocument =
                documentRepository.save(document);

        return convertToDTO(updatedDocument);
    }

    // Create a version when the existing document file is replaced
    private void createVersionForUpdate(
            Document document,
            User user,
            MultipartFile newFile) throws IOException {

        List<DocumentVersion> versions =
                documentVersionRepository
                        .findByDocumentIdOrderByVersionNumberAsc(
                                document.getId()
                        );

        // If this document has no version history yet, preserve the current file as V1
        if (versions.isEmpty()) {

            if (document.getFilePath() != null &&
                    Files.exists(
                            Paths.get(document.getFilePath())
                    )) {

                DocumentVersion firstVersion =
                        new DocumentVersion();

                firstVersion.setVersionNumber(1);
                firstVersion.setFileName(
                        document.getFileName()
                );
                firstVersion.setFileType(
                        document.getFileType()
                );
                firstVersion.setFilePath(
                        document.getFilePath()
                );
                firstVersion.setCreatedAt(
                        LocalDateTime.now()
                );
                firstVersion.setDocument(document);
                firstVersion.setUploadedBy(
                        document.getUploadedBy()
                );

                documentVersionRepository.save(
                        firstVersion
                );

                versions =
                        documentVersionRepository
                                .findByDocumentIdOrderByVersionNumberAsc(
                                        document.getId()
                                );
            }
        }

        // Calculate hash of the new file
        String newFileHash =
                calculateHash(
                        newFile.getBytes()
                );

        // Compare with every previous version
        for (DocumentVersion version : versions) {

            Path oldFilePath =
                    Paths.get(
                                    version.getFilePath()
                            )
                            .toAbsolutePath()
                            .normalize();

            if (!Files.exists(oldFilePath)) {
                continue;
            }

            byte[] oldFileBytes =
                    Files.readAllBytes(oldFilePath);

            String oldFileHash =
                    calculateHash(oldFileBytes);

            if (newFileHash.equals(oldFileHash)) {

                throw new DuplicateVersionException(
                        "This file is already available in version history. No new version was created."
                );
            }
        }

        int nextVersion =
                versions.stream()
                        .mapToInt(
                                DocumentVersion::getVersionNumber
                        )
                        .max()
                        .orElse(0) + 1;

        String uploadDirectory =
                "uploads/versions/";

        Files.createDirectories(
                Paths.get(uploadDirectory)
        );

        String originalFileName =
                newFile.getOriginalFilename();

        if (originalFileName == null ||
                originalFileName.trim().isEmpty()) {

            originalFileName =
                    "document-file";
        }

        String safeFileName =
                originalFileName.replaceAll(
                        "[^a-zA-Z0-9._-]",
                        "_"
                );

        String storedFileName =
                document.getId() +
                        "_v" +
                        nextVersion +
                        "_" +
                        safeFileName;

        Path newFilePath =
                Paths.get(
                        uploadDirectory +
                                storedFileName
                );

        Files.write(
                newFilePath,
                newFile.getBytes()
        );

        // Update the main document to the latest file
        document.setFileName(
                originalFileName
        );

        document.setFileType(
                newFile.getContentType()
        );

        document.setFilePath(
                newFilePath.toString()
        );

        // Create new version
        DocumentVersion newVersion =
                new DocumentVersion();

        newVersion.setVersionNumber(
                nextVersion
        );

        newVersion.setFileName(
                originalFileName
        );

        newVersion.setFileType(
                newFile.getContentType()
        );

        newVersion.setFilePath(
                newFilePath.toString()
        );

        newVersion.setCreatedAt(
                LocalDateTime.now()
        );

        newVersion.setDocument(
                document
        );

        newVersion.setUploadedBy(
                user
        );

        documentVersionRepository.save(
                newVersion
        );

        // Create audit log
        AuditLog auditLog =
                new AuditLog();

        auditLog.setAction(
                "CREATE_VERSION"
        );

        auditLog.setDescription(
                "Created version " +
                        nextVersion +
                        " for document " +
                        document.getId()
        );

        auditLog.setCreatedAt(
                LocalDateTime.now()
        );

        auditLog.setUser(user);

        auditLog.setDocument(document);

        auditLogRepository.save(
                auditLog
        );
    }

    // Calculate SHA-256 hash
    private String calculateHash(
            byte[] data) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] hash =
                    digest.digest(data);

            StringBuilder hexString =
                    new StringBuilder();

            for (byte b : hash) {

                String hex =
                        Integer.toHexString(
                                0xff & b
                        );

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException(
                    "SHA-256 algorithm not available",
                    e
            );
        }
    }

    // Upload a completely new document
    public DocumentDTO uploadDocument(
            MultipartFile file,
            String title,
            String description,
            Long categoryId)
            throws IOException {

        if (file == null || file.isEmpty()) {

            throw new IllegalArgumentException(
                    "Please select a file"
            );
        }

        String uploadDirectory =
                "uploads/";

        Files.createDirectories(
                Paths.get(uploadDirectory)
        );

        String originalFileName =
                file.getOriginalFilename();

        if (originalFileName == null ||
                originalFileName.trim().isEmpty()) {

            originalFileName =
                    "document-file";
        }

        String safeFileName =
                originalFileName.replaceAll(
                        "[^a-zA-Z0-9._-]",
                        "_"
                );

        Path filePath =
                Paths.get(
                        uploadDirectory +
                                safeFileName
                );

        Files.write(
                filePath,
                file.getBytes()
        );

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        String email =
                authentication.getName();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow();

        Document document =
                new Document();

        document.setTitle(title);
        document.setDescription(description);
        document.setFileName(originalFileName);
        document.setFileType(file.getContentType());
        document.setFilePath(filePath.toString());
        document.setUploadedBy(user);

        if (categoryId != null) {

            Category category =
                    categoryRepository
                            .findById(categoryId)
                            .orElseThrow();

            document.setCategory(category);
        }

        Document savedDocument =
                documentRepository.save(document);

        // Initial upload becomes V1
        DocumentVersion firstVersion =
                new DocumentVersion();

        firstVersion.setVersionNumber(1);
        firstVersion.setFileName(
                originalFileName
        );
        firstVersion.setFileType(
                file.getContentType()
        );
        firstVersion.setFilePath(
                filePath.toString()
        );
        firstVersion.setCreatedAt(
                LocalDateTime.now()
        );
        firstVersion.setDocument(
                savedDocument
        );
        firstVersion.setUploadedBy(user);

        documentVersionRepository.save(
                firstVersion
        );

        // Create audit log
        AuditLog auditLog =
                new AuditLog();

        auditLog.setAction("UPLOAD");

        auditLog.setDescription(
                "Uploaded document " +
                        originalFileName +
                        " as version 1"
        );

        auditLog.setCreatedAt(
                LocalDateTime.now()
        );

        auditLog.setUser(user);

        auditLog.setDocument(
                savedDocument
        );

        auditLogRepository.save(
                auditLog
        );

        return convertToDTO(
                savedDocument
        );
    }

    // Download current document
    public Resource downloadDocument(
            Long id)
            throws IOException {

        Document document =
                documentRepository
                        .findById(id)
                        .orElseThrow();

        Path filePath =
                Paths.get(
                                document.getFilePath()
                        )
                        .toAbsolutePath()
                        .normalize();

        Resource resource =
                new UrlResource(
                        filePath.toUri()
                );

        if (!resource.exists() ||
                !resource.isReadable()) {

            throw new IOException(
                    "File not found or cannot be read"
            );
        }

        return resource;
    }

    // Search by title
    public List<DocumentDTO> searchDocuments(
            String keyword) {

        return documentRepository
                .findByTitleContainingIgnoreCase(
                        keyword
                )
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    // Search by file type
    public List<DocumentDTO> searchByFileType(
            String fileType) {

        return documentRepository
                .findByFileTypeContainingIgnoreCase(
                        fileType
                )
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    // Get documents by category
    public List<DocumentDTO> getDocumentsByCategory(
            Long categoryId) {

        return documentRepository
                .findByCategoryId(categoryId)
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    // Delete document
    public void deleteDocument(
            Long id) {

        Document document =
                documentRepository
                        .findById(id)
                        .orElseThrow();

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        String email =
                authentication.getName();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow();

        AuditLog auditLog =
                new AuditLog();

        auditLog.setAction("DELETE");

        auditLog.setDescription(
                "Deleted document " +
                        document.getFileName()
        );

        auditLog.setCreatedAt(
                LocalDateTime.now()
        );

        auditLog.setUser(user);

        auditLog.setDocument(document);

        auditLogRepository.save(auditLog);

        List<AuditLog> auditLogs =
                auditLogRepository
                        .findAll()
                        .stream()
                        .filter(log ->
                                log.getDocument() != null &&
                                        log.getDocument()
                                                .getId()
                                                .equals(id)
                        )
                        .toList();

        auditLogs.forEach(
                log -> log.setDocument(null)
        );

        auditLogRepository.saveAll(
                auditLogs
        );

        List<DocumentVersion> versions =
                documentVersionRepository
                        .findAll()
                        .stream()
                        .filter(version ->
                                version.getDocument() != null &&
                                        version.getDocument()
                                                .getId()
                                                .equals(id)
                        )
                        .toList();

        documentVersionRepository.deleteAll(
                versions
        );

        documentRepository.delete(
                document
        );
    }

    // Convert entity to DTO
    private DocumentDTO convertToDTO(
            Document document) {

        DocumentDTO documentDTO =
                new DocumentDTO();

        documentDTO.setId(
                document.getId()
        );

        documentDTO.setTitle(
                document.getTitle()
        );

        documentDTO.setDescription(
                document.getDescription()
        );

        documentDTO.setFileName(
                document.getFileName()
        );

        documentDTO.setFileType(
                document.getFileType()
        );

        documentDTO.setFilePath(
                document.getFilePath()
        );

        if (document.getUploadedBy() != null) {

            documentDTO.setUploadedBy(
                    document.getUploadedBy().getId()
            );
        }

        if (document.getCategory() != null) {

            documentDTO.setCategoryId(
                    document.getCategory().getId()
            );
        }

        return documentDTO;
    }

    // Used when an identical file already exists in version history
    public static class DuplicateVersionException
            extends RuntimeException {

        public DuplicateVersionException(
                String message) {

            super(message);
        }
    }
}