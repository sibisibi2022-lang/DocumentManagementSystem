package com.docuvault.backend.service;

import com.docuvault.backend.dto.DocumentVersionDTO;
import com.docuvault.backend.entity.AuditLog;
import com.docuvault.backend.entity.Document;
import com.docuvault.backend.entity.DocumentVersion;
import com.docuvault.backend.entity.User;
import com.docuvault.backend.repository.AuditLogRepository;
import com.docuvault.backend.repository.DocumentRepository;
import com.docuvault.backend.repository.DocumentVersionRepository;
import com.docuvault.backend.repository.UserRepository;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class DocumentVersionService {

    private final DocumentVersionRepository documentVersionRepository;
    private final DocumentRepository documentRepository;
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;

    public DocumentVersionService(
            DocumentVersionRepository documentVersionRepository,
            DocumentRepository documentRepository,
            UserRepository userRepository,
            AuditLogRepository auditLogRepository) {

        this.documentVersionRepository =
                documentVersionRepository;

        this.documentRepository =
                documentRepository;

        this.userRepository =
                userRepository;

        this.auditLogRepository =
                auditLogRepository;
    }

    // Create a new version only when the file is different from all existing versions
    public DocumentVersionDTO createVersion(
            Long documentId,
            MultipartFile file) throws IOException {

        if (file == null || file.isEmpty()) {

            throw new IllegalArgumentException(
                    "Please select a file"
            );
        }

        Document document =
                documentRepository
                        .findById(documentId)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Document not found"
                                )
                        );

        Authentication authentication =
                SecurityContextHolder
                        .getContext()
                        .getAuthentication();

        if (authentication == null ||
                !authentication.isAuthenticated()) {

            throw new RuntimeException(
                    "User is not authenticated"
            );
        }

        String email =
                authentication.getName();

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "User not found"
                                )
                        );

        // Only ADMIN and MANAGER can create versions
        String role =
                user.getRole()
                        .toString()
                        .toUpperCase();

        if (!role.equals("ADMIN") &&
                !role.equals("MANAGER")) {

            throw new RuntimeException(
                    "You are not allowed to create document versions"
            );
        }

        List<DocumentVersion> versions =
                documentVersionRepository
                        .findByDocumentIdOrderByVersionNumberAsc(
                                documentId
                        );

        // Calculate hash of the uploaded file
        String newFileHash =
                calculateHash(file.getBytes());

        // Check the uploaded file against every existing version
        for (DocumentVersion existingVersion : versions) {

            Path existingFilePath =
                    Paths.get(
                                    existingVersion.getFilePath()
                            )
                            .toAbsolutePath()
                            .normalize();

            if (!Files.exists(existingFilePath)) {
                continue;
            }

            byte[] existingFileBytes =
                    Files.readAllBytes(
                            existingFilePath
                    );

            String existingFileHash =
                    calculateHash(
                            existingFileBytes
                    );

            if (newFileHash.equals(existingFileHash)) {

                throw new IllegalArgumentException(
                        "This file is already available in version history. No new version was created."
                );
            }
        }

        int nextVersion =
                versions.stream()
                        .mapToInt(
                                DocumentVersion::getVersionNumber
                        )
                        .max()
                        .orElse(0) + 1;

        String uploadDirectory =
                "uploads/versions/";

        Files.createDirectories(
                Paths.get(uploadDirectory)
        );

        String originalFileName =
                file.getOriginalFilename();

        if (originalFileName == null ||
                originalFileName.trim().isEmpty()) {

            originalFileName =
                    "document-file";
        }

        String safeFileName =
                originalFileName
                        .replaceAll(
                                "[^a-zA-Z0-9._-]",
                                "_"
                        );

        String storedFileName =
                documentId +
                        "_v" +
                        nextVersion +
                        "_" +
                        safeFileName;

        Path filePath =
                Paths.get(
                        uploadDirectory +
                                storedFileName
                );

        Files.write(
                filePath,
                file.getBytes()
        );

        // Update main document to the newest version
        document.setFileName(
                originalFileName
        );

        document.setFileType(
                file.getContentType()
        );

        document.setFilePath(
                filePath.toString()
        );

        documentRepository.save(
                document
        );

        // Create version
        DocumentVersion version =
                new DocumentVersion();

        version.setVersionNumber(
                nextVersion
        );

        version.setFileName(
                originalFileName
        );

        version.setFileType(
                file.getContentType()
        );

        version.setFilePath(
                filePath.toString()
        );

        version.setCreatedAt(
                LocalDateTime.now()
        );

        version.setDocument(
                document
        );

        version.setUploadedBy(
                user
        );

        DocumentVersion savedVersion =
                documentVersionRepository.save(
                        version
                );

        // Create audit log
        AuditLog auditLog =
                new AuditLog();

        auditLog.setAction(
                "CREATE_VERSION"
        );

        auditLog.setDescription(
                "Created version " +
                        nextVersion +
                        " for document " +
                        documentId
        );

        auditLog.setCreatedAt(
                LocalDateTime.now()
        );

        auditLog.setUser(
                user
        );

        auditLog.setDocument(
                document
        );

        auditLogRepository.save(
                auditLog
        );

        return convertToDTO(
                savedVersion
        );
    }

    // Calculate SHA-256 hash of file content
    private String calculateHash(
            byte[] data) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] hash =
                    digest.digest(data);

            StringBuilder hexString =
                    new StringBuilder();

            for (byte b : hash) {

                String hex =
                        Integer.toHexString(
                                0xff & b
                        );

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException(
                    "SHA-256 algorithm not available",
                    e
            );
        }
    }

    // Get all versions of a document
    public List<DocumentVersionDTO>
    getVersionsByDocumentId(
            Long documentId) {

        return documentVersionRepository
                .findByDocumentIdOrderByVersionNumberAsc(
                        documentId
                )
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    // Download one version
    public Resource downloadVersion(
            Long versionId)
            throws IOException {

        DocumentVersion version =
                documentVersionRepository
                        .findById(versionId)
                        .orElseThrow(
                                () -> new RuntimeException(
                                        "Version not found"
                                )
                        );

        Path filePath =
                Paths.get(
                                version.getFilePath()
                        )
                        .toAbsolutePath()
                        .normalize();

        if (!Files.exists(filePath)) {

            throw new IOException(
                    "Version file not found"
            );
        }

        Resource resource =
                new UrlResource(
                        filePath.toUri()
                );

        if (!resource.exists() ||
                !resource.isReadable()) {

            throw new IOException(
                    "Version file cannot be read"
            );
        }

        return resource;
    }

    // Convert entity to DTO
    private DocumentVersionDTO convertToDTO(
            DocumentVersion version) {

        DocumentVersionDTO dto =
                new DocumentVersionDTO();

        dto.setId(
                version.getId()
        );

        dto.setVersionNumber(
                version.getVersionNumber()
        );

        dto.setFileName(
                version.getFileName()
        );

        dto.setFileType(
                version.getFileType()
        );

        dto.setFilePath(
                version.getFilePath()
        );

        dto.setCreatedAt(
                version.getCreatedAt()
        );

        if (version.getDocument() != null) {

            dto.setDocumentId(
                    version.getDocument().getId()
            );
        }

        if (version.getUploadedBy() != null) {

            dto.setUploadedBy(
                    version.getUploadedBy().getId()
            );
        }

        return dto;
    }
}