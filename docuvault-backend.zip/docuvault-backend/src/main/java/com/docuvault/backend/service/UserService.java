package com.docuvault.backend.service;

import com.docuvault.backend.dto.UserDTO;
import com.docuvault.backend.entity.User;
import com.docuvault.backend.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service // Handles user business logic
public class UserService {

    private final UserRepository userRepository;


    public UserService(
            UserRepository userRepository) {

        this.userRepository =
                userRepository;
    }


    public UserDTO createUser(
            UserDTO userDTO) {

        User user =
                new User();

        user.setName(
                userDTO.getName()
        );

        user.setEmail(
                userDTO.getEmail()
        );

        user.setRole(
                userDTO.getRole()
        );

        User savedUser =
                userRepository.save(user);

        return convertToDTO(savedUser);
    }


    public List<UserDTO> getAllUsers() {

        return userRepository
                .findAll()
                .stream()
                .map(this::convertToDTO)
                .toList();
    }


    public Optional<UserDTO> getUserById(
            Long id) {

        return userRepository
                .findById(id)
                .map(this::convertToDTO);
    }


    public UserDTO getUserByEmail(
            String email) {

        User user =
                userRepository
                        .findByEmail(email)
                        .orElseThrow();

        return convertToDTO(user);
    }


    public UserDTO updateUser(
            UserDTO userDTO) {

        User user =
                userRepository
                        .findById(
                                userDTO.getId()
                        )
                        .orElseThrow();

        user.setName(
                userDTO.getName()
        );

        user.setEmail(
                userDTO.getEmail()
        );

        user.setRole(
                userDTO.getRole()
        );

        User updatedUser =
                userRepository.save(user);

        return convertToDTO(updatedUser);
    }


    public void deleteUser(Long id) {

        userRepository.deleteById(id);
    }


    private UserDTO convertToDTO(
            User user) {

        UserDTO userDTO =
                new UserDTO();

        userDTO.setId(
                user.getId()
        );

        userDTO.setName(
                user.getName()
        );

        userDTO.setEmail(
                user.getEmail()
        );

        userDTO.setRole(
                user.getRole()
        );

        return userDTO;
    }
}