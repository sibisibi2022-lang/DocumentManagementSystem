package com.docuvault.backend.controller;

import com.docuvault.backend.dto.DocumentVersionDTO;
import com.docuvault.backend.service.DocumentVersionService;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/document-versions")
public class DocumentVersionController {

    private final DocumentVersionService documentVersionService;

    public DocumentVersionController(
            DocumentVersionService documentVersionService) {

        this.documentVersionService =
                documentVersionService;
    }

    @PostMapping("/{documentId}")
    public ResponseEntity<?> createVersion(
            @PathVariable Long documentId,
            @RequestParam("file") MultipartFile file) {

        try {

            DocumentVersionDTO version =
                    documentVersionService.createVersion(
                            documentId,
                            file
                    );

            return ResponseEntity.ok(version);

        } catch (IllegalArgumentException e) {

            // Duplicate file or missing file
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(e.getMessage());

        } catch (RuntimeException e) {

            return ResponseEntity
                    .status(HttpStatus.FORBIDDEN)
                    .body(e.getMessage());

        } catch (IOException e) {

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/{documentId}")
    public ResponseEntity<List<DocumentVersionDTO>>
    getVersions(
            @PathVariable Long documentId) {

        return ResponseEntity.ok(
                documentVersionService
                        .getVersionsByDocumentId(
                                documentId
                        )
        );
    }

    @GetMapping("/{versionId}/download")
    public ResponseEntity<Resource>
    downloadVersion(
            @PathVariable Long versionId)
            throws IOException {

        Resource resource =
                documentVersionService
                        .downloadVersion(
                                versionId
                        );

        return ResponseEntity.ok()
                .contentType(
                        MediaType.APPLICATION_OCTET_STREAM
                )
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" +
                                resource.getFilename() +
                                "\""
                )
                .body(resource);
    }
}