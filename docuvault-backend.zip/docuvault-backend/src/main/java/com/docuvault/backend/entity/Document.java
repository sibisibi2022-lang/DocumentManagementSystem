package com.docuvault.backend.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.time.LocalDateTime;
@Entity // Marks this class as a database entity
public class Document { // Defines Document entity
    @Id // Marks id as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Automatically generates ID
    private Long id; // Stores document ID
    private String title; // Stores document title
    private String description; // Stores document description
    private String fileName; // Stores uploaded file name
    private String fileType; // Stores file type
    private String filePath; // Stores file location
    private LocalDateTime createdAt; // Stores document creation time
    private LocalDateTime updatedAt; // Stores document update time
    @ManyToOne // Many documents can belong to one user
    @JoinColumn(name = "uploaded_by") // Creates the uploaded_by foreign key column
    private User uploadedBy; // Stores the user who uploaded the document
    @ManyToOne // Many documents can belong to one category
    @JoinColumn(name = "category_id") // Creates the category_id foreign key column
    private Category category; // Stores the document category
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
    public String getFilePath() {
        return filePath;
    }
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    public User getUploadedBy() {
        return uploadedBy;
    }
    public void setUploadedBy(User uploadedBy) {
        this.uploadedBy = uploadedBy;
    }
    public Category getCategory() {
        return category;
    }
    public void setCategory(Category category) {
        this.category = category;
    }
}