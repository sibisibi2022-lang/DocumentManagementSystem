package com.docuvault.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service // Tells Spring that this class handles JWT operations
public class JwtService { // Defines the class responsible for creating and reading JWT tokens

    private final String secretKey = "DocuVaultSecretKeyForJwtAuthentication2026Secure"; // Secret key used to sign JWT tokens
    private final long expirationTime = 1000 * 60 * 60; // Token remains valid for 1 hour

    private SecretKey getSigningKey() { // Creates the signing key used by JWT
        return Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8)); // Converts the secret text into a secure key
    }

    public String generateToken(UserDetails userDetails) { // Creates a JWT token for a logged-in user
        return Jwts.builder()
                .subject(userDetails.getUsername()) // Stores the user's email inside the token
                .issuedAt(new Date()) // Stores the time when the token was created
                .expiration(new Date(System.currentTimeMillis() + expirationTime)) // Sets the token expiration time
                .signWith(getSigningKey()) // Signs the token using our secret key
                .compact(); // Converts everything into the final JWT string
    }

    public String extractUsername(String token) { // Extracts the username/email from a JWT token
        return extractAllClaims(token).getSubject();
    }

    private Claims extractAllClaims(String token) { // Reads all information stored inside the JWT
        return Jwts.parser()
                .verifyWith(getSigningKey()) // Verifies that the token was created using our secret key
                .build()
                .parseSignedClaims(token) // Reads and validates the token
                .getPayload(); // Gets the claims stored inside the token
    }

    public boolean isTokenValid(String token, UserDetails userDetails) { // Checks whether the JWT belongs to the correct user
        String username = extractUsername(token); // Gets the email stored in the token
        return username.equals(userDetails.getUsername()) && !isTokenExpired(token);
    }

    private boolean isTokenExpired(String token) { // Checks whether the JWT has expired
        return extractAllClaims(token).getExpiration().before(new Date());
    }
}