package com.docuvault.backend.service;

import com.docuvault.backend.dto.AuditLogDTO;
import com.docuvault.backend.entity.AuditLog;
import com.docuvault.backend.entity.Document;
import com.docuvault.backend.entity.User;
import com.docuvault.backend.repository.AuditLogRepository;
import com.docuvault.backend.repository.DocumentRepository;
import com.docuvault.backend.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service // Handles audit log business logic
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;
    private final DocumentRepository documentRepository;

    public AuditLogService(
            AuditLogRepository auditLogRepository,
            UserRepository userRepository,
            DocumentRepository documentRepository) {

        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
        this.documentRepository = documentRepository;
    }

    public AuditLogDTO createLog(AuditLogDTO auditLogDTO) {

        AuditLog auditLog = new AuditLog();

        auditLog.setAction(auditLogDTO.getAction());
        auditLog.setDescription(auditLogDTO.getDescription());
        auditLog.setCreatedAt(
                auditLogDTO.getCreatedAt() != null
                        ? auditLogDTO.getCreatedAt()
                        : LocalDateTime.now()
        );

        if (auditLogDTO.getUserId() != null) {

            User user = userRepository
                    .findById(auditLogDTO.getUserId())
                    .orElseThrow();

            auditLog.setUser(user);
        }

        if (auditLogDTO.getDocumentId() != null) {

            Document document = documentRepository
                    .findById(auditLogDTO.getDocumentId())
                    .orElseThrow();

            auditLog.setDocument(document);
        }

        AuditLog savedLog = auditLogRepository.save(auditLog);

        return convertToDTO(savedLog);
    }

    public List<AuditLogDTO> getAllLogs() {

        return auditLogRepository
                .findAll()
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    public Optional<AuditLogDTO> getLogById(Long id) {

        return auditLogRepository
                .findById(id)
                .map(this::convertToDTO);
    }

    public AuditLogDTO updateLog(AuditLogDTO auditLogDTO) {

        AuditLog auditLog = auditLogRepository
                .findById(auditLogDTO.getId())
                .orElseThrow();

        auditLog.setAction(auditLogDTO.getAction());
        auditLog.setDescription(auditLogDTO.getDescription());

        if (auditLogDTO.getCreatedAt() != null) {
            auditLog.setCreatedAt(auditLogDTO.getCreatedAt());
        }

        if (auditLogDTO.getUserId() != null) {

            User user = userRepository
                    .findById(auditLogDTO.getUserId())
                    .orElseThrow();

            auditLog.setUser(user);
        }

        if (auditLogDTO.getDocumentId() != null) {

            Document document = documentRepository
                    .findById(auditLogDTO.getDocumentId())
                    .orElseThrow();

            auditLog.setDocument(document);
        } else {
            auditLog.setDocument(null);
        }

        AuditLog updatedLog = auditLogRepository.save(auditLog);

        return convertToDTO(updatedLog);
    }

    public void deleteLog(Long id) {

        auditLogRepository.deleteById(id);
    }

    private AuditLogDTO convertToDTO(AuditLog auditLog) {

        AuditLogDTO auditLogDTO = new AuditLogDTO();

        auditLogDTO.setId(auditLog.getId());
        auditLogDTO.setAction(auditLog.getAction());
        auditLogDTO.setDescription(auditLog.getDescription());
        auditLogDTO.setCreatedAt(auditLog.getCreatedAt());

        if (auditLog.getUser() != null) {

            auditLogDTO.setUserId(
                    auditLog.getUser().getId()
            );

            auditLogDTO.setUserName(
                    auditLog.getUser().getName()
            );
        }

        if (auditLog.getDocument() != null) {

            auditLogDTO.setDocumentId(
                    auditLog.getDocument().getId()
            );
        }

        return auditLogDTO;
    }
}