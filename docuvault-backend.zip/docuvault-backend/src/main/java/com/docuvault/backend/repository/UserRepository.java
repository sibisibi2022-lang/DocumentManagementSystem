package com.docuvault.backend.repository;

import com.docuvault.backend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    // Finds a user using their email address
    Optional<User> findByEmail(String email);
}