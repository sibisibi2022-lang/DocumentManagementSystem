package com.docuvault.backend.dto;
public class UserDTO { // Defines UserDTO for transferring user data
    private Long id; // Stores user ID
    private String name; // Stores user name
    private String email; // Stores user email
    private String role; // Stores user role
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
}