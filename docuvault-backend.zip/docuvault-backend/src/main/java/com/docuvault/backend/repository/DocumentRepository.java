package com.docuvault.backend.repository;

import com.docuvault.backend.entity.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DocumentRepository extends JpaRepository<Document, Long> {

    // Finds documents whose title contains the given keyword
    List<Document> findByTitleContainingIgnoreCase(String keyword);

    // Finds documents whose file type contains the given value
    List<Document> findByFileTypeContainingIgnoreCase(String fileType);

    // Finds documents that belong to a specific category
    List<Document> findByCategoryId(Long categoryId);
}