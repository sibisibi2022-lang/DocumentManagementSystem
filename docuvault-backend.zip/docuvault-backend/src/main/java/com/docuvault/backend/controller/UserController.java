package com.docuvault.backend.controller;

import com.docuvault.backend.dto.UserDTO;
import com.docuvault.backend.service.UserService;

import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;


    public UserController(
            UserService userService) {

        this.userService =
                userService;
    }


    @PostMapping
    public UserDTO createUser(
            @RequestBody UserDTO userDTO) {

        return userService.createUser(
                userDTO
        );
    }


    @GetMapping
    public List<UserDTO> getAllUsers() {

        return userService.getAllUsers();
    }


    // Gets the currently logged-in user's profile
    @GetMapping("/profile")
    public ResponseEntity<UserDTO> getProfile(
            Authentication authentication) {

        String email =
                authentication.getName();

        UserDTO user =
                userService.getUserByEmail(
                        email
                );

        return ResponseEntity.ok(user);
    }


    // Updates the currently logged-in user's profile
    @PutMapping("/profile")
    public ResponseEntity<UserDTO> updateProfile(
            Authentication authentication,
            @RequestBody UserDTO userDTO) {

        String email =
                authentication.getName();

        UserDTO currentUser =
                userService.getUserByEmail(
                        email
                );

        userDTO.setId(
                currentUser.getId()
        );

        userDTO.setRole(
                currentUser.getRole()
        );

        UserDTO updatedUser =
                userService.updateUser(
                        userDTO
                );

        return ResponseEntity.ok(
                updatedUser
        );
    }


    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(
            @PathVariable Long id) {

        return userService
                .getUserById(id)
                .map(ResponseEntity::ok)
                .orElse(
                        ResponseEntity
                                .notFound()
                                .build()
                );
    }


    // ADMIN can update other users
    @PutMapping
    public UserDTO updateUser(
            @RequestBody UserDTO userDTO) {

        return userService.updateUser(
                userDTO
        );
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(
            @PathVariable Long id) {

        userService.deleteUser(id);

        return ResponseEntity
                .noContent()
                .build();
    }
}