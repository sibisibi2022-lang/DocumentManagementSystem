package com.docuvault.backend.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.time.LocalDateTime;
@Entity // Marks this class as a database entity
public class AuditLog { // Defines AuditLog entity
    @Id // Marks id as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Automatically generates ID
    private Long id; // Stores audit log ID
    private String action; // Stores the action performed
    private String description; // Stores details about the action
    private LocalDateTime createdAt; // Stores when the action happened
    @ManyToOne // Many audit logs can belong to one user
    @JoinColumn(name = "user_id") // Creates foreign key for user
    private User user; // Stores the user who performed the action
    @ManyToOne // Many audit logs can belong to one document
    @JoinColumn(name = "document_id") // Creates foreign key for document
    private Document document; // Stores the document related to the action
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public Document getDocument() {
        return document;
    }
    public void setDocument(Document document) {
        this.document = document;
    }
}