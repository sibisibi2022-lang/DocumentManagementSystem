package com.docuvault.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocuvaultBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(DocuvaultBackendApplication.class, args);
    }

}
