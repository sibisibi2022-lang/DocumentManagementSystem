package com.docuvault.backend.controller;
import com.docuvault.backend.dto.AuditLogDTO;
import com.docuvault.backend.service.AuditLogService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController // Marks this class as a REST Controller
@RequestMapping("/api/audit-logs") // Defines the base URL for audit log APIs
public class AuditLogController { // Defines AuditLogController
    private final AuditLogService auditLogService; // Stores AuditLogService
    public AuditLogController(AuditLogService auditLogService) { // Constructor injection
        this.auditLogService = auditLogService; // Assigns service
    }
    @PostMapping // Handles POST requests to create an audit log
    public AuditLogDTO createLog(@RequestBody AuditLogDTO auditLogDTO) { // Receives AuditLogDTO
        return auditLogService.createLog(auditLogDTO);
    }
    @GetMapping // Handles GET requests to get all audit logs
    public List<AuditLogDTO> getAllLogs() { // Gets all logs as DTOs
        return auditLogService.getAllLogs();
    }
    @GetMapping("/{id}") // Handles GET request for one audit log
    public ResponseEntity<AuditLogDTO> getLogById(@PathVariable Long id) { // Gets log using ID
        return auditLogService.getLogById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping // Handles PUT requests to update an audit log
    public AuditLogDTO updateLog(@RequestBody AuditLogDTO auditLogDTO) { // Receives updated AuditLogDTO
        return auditLogService.updateLog(auditLogDTO);
    }
    @DeleteMapping("/{id}") // Handles DELETE request for an audit log
    public ResponseEntity<Void> deleteLog(@PathVariable Long id) { // Deletes log using ID
        auditLogService.deleteLog(id);
        return ResponseEntity.noContent().build();
    }
}