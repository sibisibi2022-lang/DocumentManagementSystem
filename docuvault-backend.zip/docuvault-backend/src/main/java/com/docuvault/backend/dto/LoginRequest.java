package com.docuvault.backend.dto;

public class LoginRequest {

    private String email; // Stores the email entered during login
    private String password; // Stores the password entered during login

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}