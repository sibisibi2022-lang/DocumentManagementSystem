package com.docuvault.backend.service;

import com.docuvault.backend.dto.AuthResponse;
import com.docuvault.backend.dto.LoginRequest;
import com.docuvault.backend.dto.RegisterRequest;
import com.docuvault.backend.entity.User;
import com.docuvault.backend.exception.DuplicateEmailException;
import com.docuvault.backend.repository.UserRepository;
import com.docuvault.backend.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service // Tells Spring that this class contains authentication business logic
public class AuthService { // Defines the authentication service

    private final UserRepository userRepository; // Used to access users from MySQL
    private final PasswordEncoder passwordEncoder; // Used to encrypt passwords
    private final AuthenticationManager authenticationManager; // Used to authenticate login
    private final JwtService jwtService; // Used to generate JWT tokens

    public AuthService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            AuthenticationManager authenticationManager,
            JwtService jwtService) { // Constructor used for dependency injection

        this.userRepository = userRepository; // Assigns UserRepository
        this.passwordEncoder = passwordEncoder; // Assigns PasswordEncoder
        this.authenticationManager = authenticationManager; // Assigns AuthenticationManager
        this.jwtService = jwtService; // Assigns JwtService
    }

    public AuthResponse register(RegisterRequest request) { // Registers a new user

        if (userRepository.findByEmail(request.getEmail()).isPresent()) { // Checks whether the email already exists
            throw new DuplicateEmailException("Email already registered"); // Stops duplicate email registration
        }

        User user = new User(); // Creates a new User entity

        user.setName(request.getName()); // Stores the user's name
        user.setEmail(request.getEmail()); // Stores the user's email
        user.setPassword(passwordEncoder.encode(request.getPassword())); // Encrypts the password
        user.setRole(request.getRole()); // Stores the user's role

        userRepository.save(user); // Saves the user into MySQL

        String token = jwtService.generateToken(
                org.springframework.security.core.userdetails.User
                        .withUsername(user.getEmail())
                        .password(user.getPassword())
                        .roles(user.getRole())
                        .build()
        ); // Generates JWT for the newly registered user

        return new AuthResponse(token);
    }

    public AuthResponse login(LoginRequest request) { // Logs in an existing user

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        ); // Checks whether email and password are correct

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found")); // Finds the authenticated user

        String token = jwtService.generateToken(
                org.springframework.security.core.userdetails.User
                        .withUsername(user.getEmail())
                        .password(user.getPassword())
                        .roles(user.getRole())
                        .build()
        ); // Generates JWT for the logged-in user

        return new AuthResponse(token);
    }
}