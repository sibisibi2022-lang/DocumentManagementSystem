package com.docuvault.backend.service;

import com.docuvault.backend.dto.CategoryDTO;
import com.docuvault.backend.entity.Category;
import com.docuvault.backend.repository.CategoryRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public CategoryDTO createCategory(CategoryDTO categoryDTO) {

        if (categoryDTO.getName() == null ||
                categoryDTO.getName().trim().isEmpty()) {

            throw new RuntimeException("Category name is required");
        }

        String name = categoryDTO.getName().trim();

        if (categoryRepository.existsByNameIgnoreCase(name)) {
            throw new RuntimeException("Category already exists");
        }

        Category category = new Category();

        category.setName(name);
        category.setDescription(categoryDTO.getDescription());
        category.setCreatedAt(LocalDateTime.now());
        category.setUpdatedAt(LocalDateTime.now());

        Category savedCategory = categoryRepository.save(category);

        return convertToDTO(savedCategory);
    }

    public List<CategoryDTO> getAllCategories() {

        return categoryRepository
                .findAll()
                .stream()
                .map(this::convertToDTO)
                .toList();
    }

    public Optional<CategoryDTO> getCategoryById(Long id) {

        return categoryRepository
                .findById(id)
                .map(this::convertToDTO);
    }

    public CategoryDTO updateCategory(CategoryDTO categoryDTO) {

        Category category = categoryRepository
                .findById(categoryDTO.getId())
                .orElseThrow(() ->
                        new RuntimeException("Category not found"));

        if (categoryDTO.getName() == null ||
                categoryDTO.getName().trim().isEmpty()) {

            throw new RuntimeException("Category name is required");
        }

        String name = categoryDTO.getName().trim();

        Optional<Category> existingCategory =
                categoryRepository.findByNameIgnoreCase(name);

        if (existingCategory.isPresent() &&
                !existingCategory.get().getId()
                        .equals(categoryDTO.getId())) {

            throw new RuntimeException("Category already exists");
        }

        category.setName(name);
        category.setDescription(categoryDTO.getDescription());
        category.setUpdatedAt(LocalDateTime.now());

        Category updatedCategory =
                categoryRepository.save(category);

        return convertToDTO(updatedCategory);
    }

    public void deleteCategory(Long id) {

        if (!categoryRepository.existsById(id)) {
            throw new RuntimeException("Category not found");
        }

        categoryRepository.deleteById(id);
    }

    private CategoryDTO convertToDTO(Category category) {

        CategoryDTO categoryDTO = new CategoryDTO();

        categoryDTO.setId(category.getId());
        categoryDTO.setName(category.getName());
        categoryDTO.setDescription(category.getDescription());

        return categoryDTO;
    }
}