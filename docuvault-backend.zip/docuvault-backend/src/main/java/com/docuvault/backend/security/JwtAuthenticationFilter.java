package com.docuvault.backend.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component // Tells Spring to manage this filter
public class JwtAuthenticationFilter extends OncePerRequestFilter { // Runs JWT authentication once for each request

    private final JwtService jwtService; // Used to validate JWT tokens
    private final CustomUserDetailsService userDetailsService; // Used to find users from database

    public JwtAuthenticationFilter(JwtService jwtService, CustomUserDetailsService userDetailsService) { // Constructor injection
        this.jwtService = jwtService; // Assigns JwtService
        this.userDetailsService = userDetailsService; // Assigns UserDetailsService
    }

    @Override // Overrides Spring's request filtering method
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException { // Processes each request

        String authHeader = request.getHeader("Authorization"); // Gets Authorization header

        if (authHeader == null || !authHeader.startsWith("Bearer ")) { // Checks whether JWT is present
            filterChain.doFilter(request, response); // Continues without authentication
            return;
        }

        String token = authHeader.substring(7); // Removes "Bearer " from the token

        String username = jwtService.extractUsername(token); // Extracts email from JWT

        UserDetails userDetails = userDetailsService.loadUserByUsername(username); // Finds user using email

        if (jwtService.isTokenValid(token, userDetails)) { // Checks whether JWT is valid
            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities()); // Creates authenticated user
            SecurityContextHolder.getContext().setAuthentication(authentication); // Stores authentication in Spring Security
        }

        filterChain.doFilter(request, response); // Continues processing the request
    }
}