package com.docuvault.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocuvaultBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
